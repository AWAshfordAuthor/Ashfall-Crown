ASHFALL CROWN WEBSITE
======================

FILES
-----
index.html         Main book landing page
beta-reader.html   Beta-reader application page
styles.css         Site design and mobile styling
script.js          Mobile menu and automatic copyright year

HOW TO PREVIEW IT
-----------------
Open index.html in a browser.

HOW TO MAKE THE BETA-READER FORM WORK
-------------------------------------
The included form is designed for Formspree, which lets a static website send
form submissions to your email without requiring you to build a server.

1. Create an account at Formspree.
2. Create a new form.
3. Copy the endpoint Formspree gives you. It will look similar to:
   https://formspree.io/f/abcdwxyz
4. Open beta-reader.html in a text editor.
5. Find:
   https://formspree.io/f/YOUR_FORM_ID
6. Replace it with your actual endpoint.
7. Save and re-upload the file.

You can instead replace the "Become a Beta Reader" and "Apply to Read" links in
index.html with a Google Forms, Jotform, or Mailchimp form URL.

HOW TO PUBLISH FREE
-------------------
GitHub Pages:
1. Create a GitHub account and a new public repository.
2. Upload all four website files.
3. Open Settings > Pages.
4. Select the main branch and root folder.
5. GitHub will provide the live site address.

Netlify:
1. Create a Netlify account.
2. Drag the entire ashfall_crown_website folder into Netlify's deployment area.
3. Netlify will publish it and provide a temporary address.
4. Connect a custom domain from the Domain settings.

CUSTOMIZATION CHECKLIST
-----------------------
- Replace the placeholder author biography in index.html.
- Add your final cover art when selected.
- Add social-media links.
- Connect the beta-reader form.
- Add a privacy-policy page before collecting mailing-list subscriptions.
- Connect a custom domain such as ashfallcrown.com or awashfordbooks.com.
